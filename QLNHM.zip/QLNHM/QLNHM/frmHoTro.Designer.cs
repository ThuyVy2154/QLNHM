﻿namespace QLNHM
{
    partial class frmHoTro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHoTro));
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnHoTro = new System.Windows.Forms.Button();
            this.btnQuanLyNhanVien = new System.Windows.Forms.Button();
            this.btnQuanLyYeuCauMau = new System.Windows.Forms.Button();
            this.btnSuKienHienMau = new System.Windows.Forms.Button();
            this.btnQuanLyKhoMau = new System.Windows.Forms.Button();
            this.btnNhapThongTinNguoiHien = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnTrangChu = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label28 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel14.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(83, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(313, 49);
            this.label2.TabIndex = 3;
            this.label2.Text = "BLOOD BANK";
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox15.Image")));
            this.pictureBox15.Location = new System.Drawing.Point(3, 3);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(86, 58);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox15.TabIndex = 16;
            this.pictureBox15.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(411, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(864, 49);
            this.label1.TabIndex = 17;
            this.label1.Text = "PHẦN MỀM QUẢN LÝ NGÂN HÀNG MÁU";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1290, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(52, 49);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(1348, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 29);
            this.label3.TabIndex = 19;
            this.label3.Text = "Admin";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(3, 67);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.MistyRose;
            this.splitContainer1.Panel1.Controls.Add(this.btnHoTro);
            this.splitContainer1.Panel1.Controls.Add(this.btnQuanLyNhanVien);
            this.splitContainer1.Panel1.Controls.Add(this.btnQuanLyYeuCauMau);
            this.splitContainer1.Panel1.Controls.Add(this.btnSuKienHienMau);
            this.splitContainer1.Panel1.Controls.Add(this.btnQuanLyKhoMau);
            this.splitContainer1.Panel1.Controls.Add(this.btnNhapThongTinNguoiHien);
            this.splitContainer1.Panel1.Controls.Add(this.panel2);
            this.splitContainer1.Panel1.Controls.Add(this.btnTrangChu);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.SystemColors.Control;
            this.splitContainer1.Panel2.Controls.Add(this.label4);
            this.splitContainer1.Panel2.Controls.Add(this.pictureBox2);
            this.splitContainer1.Panel2.Controls.Add(this.panel14);
            this.splitContainer1.Size = new System.Drawing.Size(1461, 834);
            this.splitContainer1.SplitterDistance = 366;
            this.splitContainer1.TabIndex = 20;
            // 
            // btnHoTro
            // 
            this.btnHoTro.BackColor = System.Drawing.Color.IndianRed;
            this.btnHoTro.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHoTro.ForeColor = System.Drawing.Color.White;
            this.btnHoTro.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHoTro.Location = new System.Drawing.Point(9, 517);
            this.btnHoTro.Name = "btnHoTro";
            this.btnHoTro.Size = new System.Drawing.Size(333, 78);
            this.btnHoTro.TabIndex = 21;
            this.btnHoTro.Text = "Hỗ trợ";
            this.btnHoTro.UseVisualStyleBackColor = false;
            // 
            // btnQuanLyNhanVien
            // 
            this.btnQuanLyNhanVien.BackColor = System.Drawing.Color.White;
            this.btnQuanLyNhanVien.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuanLyNhanVien.ForeColor = System.Drawing.Color.IndianRed;
            this.btnQuanLyNhanVien.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQuanLyNhanVien.Location = new System.Drawing.Point(9, 433);
            this.btnQuanLyNhanVien.Name = "btnQuanLyNhanVien";
            this.btnQuanLyNhanVien.Size = new System.Drawing.Size(333, 78);
            this.btnQuanLyNhanVien.TabIndex = 20;
            this.btnQuanLyNhanVien.Text = "Quản lý nhân viên";
            this.btnQuanLyNhanVien.UseVisualStyleBackColor = false;
            // 
            // btnQuanLyYeuCauMau
            // 
            this.btnQuanLyYeuCauMau.BackColor = System.Drawing.Color.White;
            this.btnQuanLyYeuCauMau.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuanLyYeuCauMau.ForeColor = System.Drawing.Color.IndianRed;
            this.btnQuanLyYeuCauMau.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQuanLyYeuCauMau.Location = new System.Drawing.Point(9, 265);
            this.btnQuanLyYeuCauMau.Name = "btnQuanLyYeuCauMau";
            this.btnQuanLyYeuCauMau.Size = new System.Drawing.Size(333, 78);
            this.btnQuanLyYeuCauMau.TabIndex = 19;
            this.btnQuanLyYeuCauMau.Text = "Quản lý yêu cầu máu";
            this.btnQuanLyYeuCauMau.UseVisualStyleBackColor = false;
            // 
            // btnSuKienHienMau
            // 
            this.btnSuKienHienMau.BackColor = System.Drawing.Color.White;
            this.btnSuKienHienMau.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuKienHienMau.ForeColor = System.Drawing.Color.IndianRed;
            this.btnSuKienHienMau.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSuKienHienMau.Location = new System.Drawing.Point(9, 349);
            this.btnSuKienHienMau.Name = "btnSuKienHienMau";
            this.btnSuKienHienMau.Size = new System.Drawing.Size(333, 78);
            this.btnSuKienHienMau.TabIndex = 18;
            this.btnSuKienHienMau.Text = "Sự kiện hiến máu";
            this.btnSuKienHienMau.UseVisualStyleBackColor = false;
            // 
            // btnQuanLyKhoMau
            // 
            this.btnQuanLyKhoMau.BackColor = System.Drawing.Color.White;
            this.btnQuanLyKhoMau.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuanLyKhoMau.ForeColor = System.Drawing.Color.IndianRed;
            this.btnQuanLyKhoMau.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQuanLyKhoMau.Location = new System.Drawing.Point(9, 181);
            this.btnQuanLyKhoMau.Name = "btnQuanLyKhoMau";
            this.btnQuanLyKhoMau.Size = new System.Drawing.Size(333, 78);
            this.btnQuanLyKhoMau.TabIndex = 17;
            this.btnQuanLyKhoMau.Text = "Quản lý kho máu";
            this.btnQuanLyKhoMau.UseVisualStyleBackColor = false;
            // 
            // btnNhapThongTinNguoiHien
            // 
            this.btnNhapThongTinNguoiHien.BackColor = System.Drawing.Color.White;
            this.btnNhapThongTinNguoiHien.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhapThongTinNguoiHien.ForeColor = System.Drawing.Color.IndianRed;
            this.btnNhapThongTinNguoiHien.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNhapThongTinNguoiHien.Location = new System.Drawing.Point(9, 97);
            this.btnNhapThongTinNguoiHien.Name = "btnNhapThongTinNguoiHien";
            this.btnNhapThongTinNguoiHien.Size = new System.Drawing.Size(333, 78);
            this.btnNhapThongTinNguoiHien.TabIndex = 16;
            this.btnNhapThongTinNguoiHien.Text = "Thông tin người hiến máu";
            this.btnNhapThongTinNguoiHien.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.IndianRed;
            this.panel2.Location = new System.Drawing.Point(353, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 834);
            this.panel2.TabIndex = 14;
            // 
            // btnTrangChu
            // 
            this.btnTrangChu.BackColor = System.Drawing.Color.White;
            this.btnTrangChu.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrangChu.ForeColor = System.Drawing.Color.IndianRed;
            this.btnTrangChu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTrangChu.Location = new System.Drawing.Point(9, 13);
            this.btnTrangChu.Name = "btnTrangChu";
            this.btnTrangChu.Size = new System.Drawing.Size(333, 78);
            this.btnTrangChu.TabIndex = 15;
            this.btnTrangChu.Text = "Trang chủ";
            this.btnTrangChu.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(431, 724);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(208, 31);
            this.label4.TabIndex = 14;
            this.label4.Text = "Hotline: 888.888";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(6, 95);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1085, 591);
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.IndianRed;
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel14.Controls.Add(this.label28);
            this.panel14.Location = new System.Drawing.Point(3, 3);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(1088, 86);
            this.panel14.TabIndex = 12;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label28.Location = new System.Drawing.Point(26, 24);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(114, 42);
            this.label28.TabIndex = 1;
            this.label28.Text = "Hỗ trợ";
            // 
            // frmHoTro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1464, 902);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.label2);
            this.Name = "frmHoTro";
            this.Text = "frmHoTro";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnTrangChu;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnQuanLyNhanVien;
        private System.Windows.Forms.Button btnQuanLyYeuCauMau;
        private System.Windows.Forms.Button btnSuKienHienMau;
        private System.Windows.Forms.Button btnQuanLyKhoMau;
        private System.Windows.Forms.Button btnNhapThongTinNguoiHien;
        private System.Windows.Forms.Button btnHoTro;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}