﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLNHM
{
    public partial class frmTrangChu : Form
    {
        public frmTrangChu()
        {
            InitializeComponent();
        }

        private void btnNhapThongTinNguoiHien_Click(object sender, EventArgs e)
        {
            frmThongTinNguoiHienMau frm = new frmThongTinNguoiHienMau();
            frm.ShowDialog();
        }

        private void btnQuanLyKhoMau_Click(object sender, EventArgs e)
        {
            frmQuanLyKhoMau frm = new frmQuanLyKhoMau();
            frm.ShowDialog();
        }

        private void btnQuanLyYeuCauMau_Click(object sender, EventArgs e)
        {
            frmQuanLyYeuCauMau frm = new frmQuanLyYeuCauMau();
            frm.ShowDialog();
        }

        private void btnSuKienHienMau_Click(object sender, EventArgs e)
        {
            frmSuKienHienMau frm = new frmSuKienHienMau();
            frm.ShowDialog();
        }

        private void btnQuanLyNhanVien_Click(object sender, EventArgs e)
        {
            frmQuanLyNhanVien frm = new frmQuanLyNhanVien();
            frm.ShowDialog();
        }

        private void btnHoTro_Click(object sender, EventArgs e)
        {
            frmHoTro frm = new frmHoTro();
            frm.ShowDialog();
        }

    }
}
