﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLNHM
{
    public partial class InGiayChungNhanHienMau : Form
    {
        public InGiayChungNhanHienMau()
        {
            InitializeComponent();
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {
            reportDocument = new ReportDocument();
            reportDocument.Load(@"Path\to\rptGiayChungNhanHienMau.rpt");

            // Thiết lập kết nối cơ sở dữ liệu nếu cần
            reportDocument.SetDatabaseLogon("username", "password", "server", "database");

            // Hiển thị báo cáo trên CrystalReportViewer
            crystalReportViewer.ReportSource = reportDocument;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // In trực tiếp báo cáo
                reportDocument.PrintToPrinter(1, false, 0, 0);
                MessageBox.Show("In thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi in báo cáo: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
